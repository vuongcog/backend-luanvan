<?php

namespace App\Http\Controllers;

use App\Models\Coupon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class CouponController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:api', ['except' => ['login', 'register']]);
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function index()
    {
        //
        $coupon = Coupon::all();
        return response()->json(['coupons' => $coupon]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function store(Request $request)
    {
        //
        $validate = [
            'discount_value' => 'required',
            'coupon_start_date' => 'date|required',
            'coupon_end_date' => 'date|required',
            'coupon_quantity' => 'required',
            'status' => 'nullable|string|in:active,inactive',
        ];
        // kiem tra du lieu input -> validate
        $validator = Validator::make($request->all(), $validate);
        // thong bao neu du lieu khong hop le
        if ($validator->fails()) {
            return response()->json(['error' => $validator->errors()], 422);
        }
        $data = [
            'coupon_code' => 'MAGIAMGIA-' . rand(999, 10000),
            'discount_value' => $request->input('discount_value'),
            'coupon_start_date' => $request->input('coupon_start_date'),
            'coupon_end_date' => $request->input('coupon_end_date'),
            'coupon_quantity' => $request->input('coupon_quantity'),
            'status' => $request->input('status'),
        ];
        $coupon = Coupon::create($data);
        if ($coupon) {
            return response()->json(['success' => 'Coupon created successfully', 'Coupon' => $coupon], 201);
        } else {
            return response()->json(['error' => 'Coupon creation failed'], 500);
        }

    }

    /**
     * Display the specified resource.
     *
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @param int $id
     * @return \Illuminate\Http\JsonResponse
     */
    public function update(Request $request, $id)
    {
        //
        $coupon = Coupon::find($id);
        if (!$coupon) {
            return response()->json(['error' => 'Coupon not found'], 404);
        }
        $validate = [
            'discount_value' => 'required',
            'coupon_start_date' => 'date|required',
            'coupon_end_date' => 'date|required',
            'coupon_quantity' => 'required',
            'status' => 'nullable|string|in:active,inactive',
        ];
        // kiem tra du lieu input -> validate
        $validator = Validator::make($request->all(), $validate);
        // thong bao neu du lieu khong hop le
        if ($validator->fails()) {
            return response()->json(['error' => $validator->errors()], 422);
        }
        $coupon->discount_value = $request->input('discount_value');
        $coupon->coupon_start_date = $request->input('coupon_start_date');
        $coupon->coupon_end_date = $request->input('coupon_end_date');
        $coupon->coupon_quantity = $request->input('coupon_quantity');
        $coupon->status = $request->input('status');
        return response()->json(['message' => 'Coupon updated successfully', 'blog' => $coupon], 201);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param int $id
     * @return \Illuminate\Http\JsonResponse
     */
    public function destroy($id)
    {
        //
        $coupon = Coupon::find($id);
        if (!$coupon) {
            return response()->json(['error' => 'Coupon not found'], 404);
        }
        $coupon->delete();
        return response()->json(['message' => 'Coupon deleted successfully']);
    }
}
